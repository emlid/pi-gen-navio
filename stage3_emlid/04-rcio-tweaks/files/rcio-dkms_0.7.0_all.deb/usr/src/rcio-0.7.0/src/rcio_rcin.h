#ifndef _RCIO_RCIN_H
#define _RCIO_RCIN_H

#include "rcio.h"

int rcio_rcin_probe(struct rcio_state* state);
bool rcio_rcin_update(struct rcio_state* state);

#endif
